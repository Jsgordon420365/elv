ELV / LegalFlowNC portable customer export
Generated: 2026-07-16T04:11:09.234Z

vault-export.json — decrypted structured parties, relationships, facts, provenance metadata, assurance records, and incident records.
latest-generated-document.docx — the latest generated document.
latest-assurance-record.json — evidence for the latest generation.
incidents.json — portable recourse records, included when incidents exist.

This archive was created only after the user explicitly selected Export and accepted the visible plaintext packaging warning.