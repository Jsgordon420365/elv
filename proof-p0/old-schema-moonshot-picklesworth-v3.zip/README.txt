Fictional encrypted ELV schema-v3 fixture created by running commit 1acfa72 at a separate localhost origin. Contains only Moonshot Marmalade / Picklesworth test identities.
